// Author: Yahel Friedman 203146808

public class Warmup {

	public static void main(String[] args) {
		
	}
	
	// **************   Task1   **************
	public static boolean doesDigitAppearInNumber(int number, int digit) {
		if (number == 0){
			return false;
		}//if	
		if (number % 10 == digit || number == digit) {
			return true;
		} //if
		else {
			return doesDigitAppearInNumber(number / 10, digit);
		}//else
		
		
	}//doesDigitAppearInNumber

	// ************** Task2 **************
	public static int countNumberOfEvenDigits(int number) {
		if (number == 0) {
			return 0;
		}//if
		if (number % 2 == 0) {
			return 1 + countNumberOfEvenDigits(number / 10);
		}//if 
		else {
			return countNumberOfEvenDigits(number / 10);
		}//else
		
		
	}//countNumberOfEvenDigits

	// ************** Task3 **************
	public static int countTheAmountOfCharInString(String str, char c) {
		if (str.length() == 0) {
			return 0;
		}//if
		if (str.charAt(0) == c) {
			return 1 + countTheAmountOfCharInString(str.substring(1), c);
		} //if
		else {
			return countTheAmountOfCharInString(str.substring(1), c);
		}//esle
		
		
	}//countTheAmountOfCharInString

	// ************** Task4 **************
	public static boolean checkIfAllLettersAreCapitalOrSmall(String str) {
		if (str.length() == 1 || str.length() == 0) {
			return true;
		}//if

		if ((str.charAt(0) >= 'A' && str.charAt(0) <= 'Z') && (str.charAt(1) >= 'A' && str.charAt(1) <= 'Z')) {
			return checkIfAllLettersAreCapitalOrSmall(str.substring(1));
		}//if
		if ((str.charAt(0) >= 'a' && str.charAt(0) <= 'z') && (str.charAt(1) >= 'a' && str.charAt(1) <= 'z')) {
			return checkIfAllLettersAreCapitalOrSmall(str.substring(1));
		}//if

		else{
			return false;
		}//else	
		
		return "";
	}//checkIfAllLettersAreCapitalOrSmall

}//class Warmup
