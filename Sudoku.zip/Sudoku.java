// Author: Yahel Friedman 203146808

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;


public class Sudoku {

	public static void main(String[] args) {
		
		int[][] board = readBoardFromFile("S1.txt");
		
	}
	
	
	// **************   Sudoku - Read Board From Input File   **************
	public static int[][] readBoardFromFile(String fileToRead){
		int[][] board = new int[9][9];
		try {
			BufferedReader bufferedReader = new BufferedReader(new FileReader(fileToRead)); // change S1.txt to any file you like (S2.txt, ...)
			int row = 0;
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				for(int column = 0; column < line.length(); column++){
					char c = line.charAt(column);
					if(c == 'X')
						board[row][column] = 0;
					else board[row][column] = c - '0';
				}
				row++;
			}
			bufferedReader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return board;
	}
	
	
	
	// **************   Sudoku - Part1 (iterative)   **************
	public static int[][][] eliminateDomains(int[][] board){
		int[][][] domains = new int[9][9][9];
		boolean flag = true;
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board[0].length; j++) {
				if (board[i][j] != 0) {
					for (int k = 0; k < domains[i][j].length; k++) {
						domains[i][j][k] = 1;
					}
					domains[i][j][board[i][j] - 1] = 0;
				}
			}
		}

		while (flag) {
			flag = false;
			int[][][] tmp = copy(domains);
			for (int i = 0; i < board.length; i++) {
				for (int j = 0; j < board[0].length; j++) {
					if (board[i][j] == 0)// the cell is not solved yet!
					{
						domains = rowColCheck(domains, board, i, j);
						domains = areaCheck(domains, board, i, j);

					}
				}
			}
			if (!myEqual(tmp, domains)) {
				flag = true;
			}

			// transfer cell info from domains to board.
			for (int row = 0; row < domains.length; row++) {
				for (int col = 0; col < domains[0].length; col++) {
					if (board[row][col] == 0) {

						int sum = 0;
						int zeroflag = 0;
						for (int options = 0; options < domains[0][0].length; options++) {
							if (domains[row][col][options] == 1) {
								sum++;
							} // if
							else {
								zeroflag = options;
							} // else
						} // for
						if (sum == 8) {
							board[row][col] = zeroflag + 1;
						} // if
					} // if
				} // for
			} // for

		} // while
		return domains;
	}// eliminateDomains

	private static boolean myEqual(int[][][] tmp, int[][][] domains) {  //returns true if tmp = equal
		boolean ans = true;
		for (int i = 0; i < domains.length; i++) {
			for (int j = 0; j < domains[0].length; j++) {
				for (int k = 0; k < domains[i][j].length; k++) {
					if (tmp[i][j][k] != domains[i][j][k]){
						return false;
					}//if	
				}//for
			}//for
		}//for
		return ans;
	}//myEqual

	public static int[][][] copy(int domains[][][]) {  // create a copy of domains
		int[][][] copy = new int[9][9][9];
		for (int i = 0; i < domains.length; i++) {
			for (int j = 0; j < domains[0].length; j++) {
				for (int k = 0; k < domains[i][j].length; k++) {
					copy[i][j][k] = domains[i][j][k];
				}//for
			}//for
		}//for
		return copy;
	}//copy

	public static int[][][] rowColCheck(int[][][] domains, int board[][], int row, int col) { //check the options for an i,j cell on board (by row-columun scan)

		for (int i = 0; i < domains.length; i++) {
			if (board[i][col] != 0 && i != row) {
				domains[row][col][board[i][col] - 1] = 1;
			}//if
		}//for

		for (int j = 0; j < domains[0].length; j++) {
			if (board[row][j] != 0 && j != col) {
				domains[row][col][board[row][j] - 1] = 1;
			}//if
		}//for

		return domains;
	}

	public static int[][][] areaCheck(int domains[][][], int board[][], int row, int col) { //splits the board to 9 areas and checks for  i,j cell options on every small section of the board
		int i;
		int j;
		if ((row == 1 || row == 2 || row == 0) && (col == 1 || col == 2 || col == 0)) // area 1
		{
			for (i = 0; i < 3; i++) {
				for (j = 0; j < 3; j++) {
					if (board[i][j] != 0) {
						domains[row][col][board[i][j] - 1] = 1;
					}//if
				}//for
			}//for
		}//if
		if ((row == 1 || row == 2 || row == 0) && (col == 4 || col == 5 || col == 3)) // area 2
		
		{
			for (i = 0; i < 3; i++) {
				for (j = 3; j < 6; j++) {
					if (board[i][j] != 0) {
						domains[row][col][board[i][j] - 1] = 1;
					}//if
				}//for
			}//for

		}//if
		if ((row == 1 || row == 2 || row == 0) && (col == 7 || col == 8 || col == 6)) // area 3
		
		{
			for (i = 0; i < 3; i++) {
				for (j = 6; j < 9; j++) {
					if (board[i][j] != 0) {
						domains[row][col][board[i][j] - 1] = 1;
					}//if
				}//for
			}//for

		}//if
		if ((row == 4 || row == 5 || row == 3) && (col == 1 || col == 2 || col == 0)) // area 4
		
		{
			for (i = 3; i < 6; i++) {
				for (j = 0; j < 3; j++) {
					if (board[i][j] != 0) {
						domains[row][col][board[i][j] - 1] = 1;
					}//if
				}//for
			}//for
		}//if
		if ((row == 4 || row == 5 || row == 3) && (col == 4 || col == 5 || col == 3)) // area 5
		
		{
			for (i = 3; i < 6; i++) {
				for (j = 3; j < 6; j++) {
					if (board[i][j] != 0) {
						domains[row][col][board[i][j] - 1] = 1;
					}//if
				}//for
			}//for
		}//if
		if ((row == 4 || row == 5 || row == 3) && (col == 7 || col == 8 || col == 6)) // area 6
		
		{
			for (i = 3; i < 6; i++) {
				for (j = 6; j < 9; j++) {
					if (board[i][j] != 0) {
						domains[row][col][board[i][j] - 1] = 1;
					}//if
				}//for
			}//for
		}//if
		if ((row == 7 || row == 8 || row == 6) && (col == 1 || col == 2 || col == 0)) // area7
		{
			for (i = 6; i < 9; i++) {
				for (j = 0; j < 3; j++) {
					if (board[i][j] != 0) {
						domains[row][col][board[i][j] - 1] = 1;
					}//if
				}//for
			}//for
		}//if
		if ((row == 7 || row == 8 || row == 6) && (col == 4 || col == 5 || col == 3)) // area 8
		
		{
			for (i = 6; i < 9; i++) {
				for (j = 3; j < 6; j++) {
					if (board[i][j] != 0) {
						domains[row][col][board[i][j] - 1] = 1;
					}//if
				}//for
			}//for
		}//if
		if ((row == 7 || row == 8 || row == 6) && (col == 7 || col == 8 || col == 6)) // area 9
		
		{
			for (i = 6; i < 9; i++) {
				for (j = 6; j < 9; j++) {
					if (board[i][j] != 0) {
						domains[row][col][board[i][j] - 1] = 1;
					}//if
				}//for
			}//for
		}//if

		return domains;

	}

	public static void printBoard(int[][][] domains, int[][] board){ 
		for (int i = 0; i < board.length; i++) {
			if (i > 0){
				System.out.println("");
			}//if	
			if (i == 3 || i == 6) {
				for (int k = 0; k < 11; k++) {
					if (k == 3 || k == 7) {
						System.out.print("+");
					}//if 
					else {
						System.out.print("-");
					}//else
				}//for
				System.out.println("");
			}//if

			for (int j = 0; j < board[0].length; j++) {

				if (j == 3 || j == 6) {
					System.out.print("|");
				}//if

				System.out.print(board[i][j]);

			}//for
	}//prinBoard
	
	
	// **************   Sudoku - Part2 (recursive)   **************
	public static boolean solveSudoku(int[][] board){
		boolean ans = false;
		int[][][] domains = eliminateDomains(board);
		int[][] copy = copyBoard(board);
		for (int i = 0; i < copy.length; i++) {
			for (int j = 0; j < copy[0].length; j++) {
				if (copy[i][j] == 0) {
					for (int k = 0; k < domains[0][0].length; k++) {
						if (domains[i][j][k] == 0) {
							copy[i][j] = k + 1;
							ans = solveSudoku(copy);

							if (ans == true) {
								return ans;
							} // if

						} // if

					} // for
				} // if
			} // for
		} // for

		if (gameOver(copy)) { // breakpoint condition1
			ans = true;
			return ans;
		}

		return ans;
	}// solveSudoku

	public static boolean gameOver(int[][] board) { //ends the game if board is full
		int counter = 0;

		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board[0].length; j++) {
				if (board[i][j] == 0) {
					return false;
				} // if

			} // for
		} // for
		return true;

	}// gameover

	public static int[][] copyBoard(int[][] board) { //make a copy of board

		int[][] copy = new int[board[0].length][board.length];
		for (int i = 0; i < board.length; i++) {
			for (int j = 0; j < board[0].length; j++) {
				copy[i][j] = board[i][j];
			}//for
		}//for
		return copy;

	}//copyBoard

		
		
	

}//class Sudoku
